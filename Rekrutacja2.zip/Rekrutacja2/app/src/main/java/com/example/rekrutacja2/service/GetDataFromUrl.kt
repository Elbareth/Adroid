package com.example.rekrutacja2.service

import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.rekrutacja2.Requests.ByteArrayRequest
import com.example.rekrutacja2.Requests.ByteArrayResponseListener
import java.net.ProtocolException

class GetDataFromUrl(val context: Context): AppCompatActivity() {
    private val queue = Volley.newRequestQueue(context)
    private val url = "http://213.73.2.250:4455/"
    private val tag = "Rekrutacja"

    fun sendRequest(){
//        val stringRequest = StringRequest(Request.Method.GET,url,
//            Response.Listener {
////                val basicDialog = BasicDialog("Send Request",it)
////                basicDialog.show(supportFragmentManager, "BasicDialog")
//                Log.d("Thread",it)
//            },
//            Response.ErrorListener {
////                val basicDialog = BasicDialog("Error", "Sorry. We cant send this request")
////                basicDialog.show(supportFragmentManager, "BasicDialog")
////                Log.d("Thread",it.cause.toString())
//                Log.d("Thread",it.message)
////                Log.d("Thread",it.message)
//            })
//        stringRequest.tag = tag
//        queue.add(stringRequest)
            val byteArrayRequest = ByteArrayRequest(Request.Method.GET,url,
                object : ByteArrayResponseListener {
                    override fun onByteArrayResponse(repsonse: ByteArray) {
                        val text: String  = repsonse.toString()
                        Log.d("Thread", text)
                    }
                },
            Response.ErrorListener {
//                val basicDialog = BasicDialog("Error", "Sorry. We cant send this request")
//                basicDialog.show(supportFragmentManager, "BasicDialog")
//                Log.d("Thread",it.cause.toString())
                if(it.cause is ProtocolException){
                    Log.d("Thread",it.message)
                    Log.d("Thread",it.localizedMessage)
                    //Log.d("Thread",it.networkResponse.data.toString())
                }
//                Log.d("Thread",it.message)
            })
        byteArrayRequest.tag = tag
        queue.add(byteArrayRequest)
    }

    override fun onStop() {
        super.onStop()
        queue.cancelAll(tag)
    }

}