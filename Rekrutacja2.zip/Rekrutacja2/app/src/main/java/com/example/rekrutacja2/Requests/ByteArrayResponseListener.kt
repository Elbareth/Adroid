package com.example.rekrutacja2.Requests

interface ByteArrayResponseListener {
    fun onByteArrayResponse(repsonse: ByteArray)
}