package com.example.rekrutacja2.Requests

import com.android.volley.NetworkResponse
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.HttpHeaderParser

class ByteArrayRequest(val i: Int, val url2: String, val listenerCorrect: ByteArrayResponseListener, val listener: Response.ErrorListener): Request<ByteArray>(i,url2,listener) {

    override fun deliverResponse(response: ByteArray?) {
        listenerCorrect.onByteArrayResponse(response?:ByteArray(0))
    }

    override fun parseNetworkResponse(response: NetworkResponse?): Response<ByteArray> {
        val data: ByteArray = response?.data?: ByteArray(0)
        return Response.success(data, HttpHeaderParser.parseCacheHeaders(response))
    }
}