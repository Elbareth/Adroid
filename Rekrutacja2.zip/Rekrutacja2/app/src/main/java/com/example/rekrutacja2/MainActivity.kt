package com.example.rekrutacja2

import android.content.Intent
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.widget.Toolbar
import com.example.rekrutacja2.activity.DataBaseActivity
import com.example.rekrutacja2.service.BasicDialog
import com.example.rekrutacja2.service.GpsService
import com.example.rekrutacja2.thread.GetDataFromUrlThread
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private var longitude: Double = 0.0
    private var latitude: Double = 0.0
    private var location: Location? = null
    private lateinit var gps: GpsService

    fun calculateLocation(){
        location = gps.getLocation()
        longitude = location?.longitude?:0.0
        latitude = location?.latitude?:0.0
//        val basicDialog = BasicDialog("position","$longitude and  $latitude")
//        basicDialog.show(supportFragmentManager, "BasicDialog")
        Log.d("Main", "$longitude and  $latitude")
    }

    override fun onMapReady(googleMap: GoogleMap?) {
        val myCurretnPosition = LatLng(latitude,longitude)
        googleMap?.addMarker(MarkerOptions().position(myCurretnPosition).title("Your current position"))
        googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(myCurretnPosition, 17.0f))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        gps = GpsService(applicationContext)
        calculateLocation()
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        Thread(GetDataFromUrlThread(applicationContext)).start()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        var intent: Intent
        when (item?.itemId){
            R.id.data_base -> {
                intent = Intent(baseContext, DataBaseActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
