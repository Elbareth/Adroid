package com.example.rekrutacja2.service

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.appcompat.app.AppCompatDialogFragment

class BasicDialog(val title: String, val message: String): AppCompatDialogFragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        super.onCreateDialog(savedInstanceState)
       val builder: AlertDialog.Builder = AlertDialog.Builder(activity)
        builder.setTitle(title)
        builder.setMessage(message)
//        builder.setPositiveButton("OK", DialogInterface.OnClickListener(){
//                dialogInterface: DialogInterface, i: Int -> dialogInterface.cancel()
//        })
        return builder.create()
    }
}