package com.example.rekrutacja2.service

import android.content.Context
import android.content.Context.LOCATION_SERVICE
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.core.content.ContextCompat

class GpsService(private val context: Context): LocationListener {

    private var locationManager: LocationManager? = null
    private var enabled = false
    private var networkEnabled = false
    private var location: Location? = null

    fun getLocation(): Location?{
        locationManager = context.getSystemService(LOCATION_SERVICE) as LocationManager?
        havePermission()
        if(checkPermission()){
          if(enabled){
              if(location == null){
                  locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 1.0f, this)
                  if(locationManager != null){
                      location = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                  }
              }
          }
          else if(location == null){
              if(networkEnabled){
                  locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000,1.0f, this)
                  if(locationManager != null){
                      location = locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                  }
              }
          }
        }
        return location
    }

    private fun havePermission(){
        enabled = locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER)?:false
        networkEnabled = locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER)?:false
    }

    private fun checkPermission(): Boolean{
        return ContextCompat.checkSelfPermission(context,android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    override fun onLocationChanged(location: Location?) {

    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {

    }

    override fun onProviderEnabled(provider: String?) {

    }

    override fun onProviderDisabled(provider: String?) {

    }

}