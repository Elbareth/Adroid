package com.example.rekrutacja2.thread

import android.content.Context
import com.example.rekrutacja2.service.GetDataFromUrl

class GetDataFromUrlThread(val context: Context): Runnable {

    private val url: GetDataFromUrl = GetDataFromUrl(context)

    override fun run() {

        while(true){
            url.sendRequest()
            Thread.sleep(200)
        }
    }
}