package com.example.rekrutacja2.dto

import com.google.android.gms.maps.model.LatLng
import java.time.LocalDate

data class DistanceDTO(
    var time: LocalDate,
    var positionOfSatellite: LatLng,
    var positionOfPhone: LatLng,
    var distance: Double
    )